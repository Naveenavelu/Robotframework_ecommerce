from typing import Dict, Any

from openpyxl import load_workbook


def read_excel_data(file_path, sheet_name):
    wb = load_workbook(filename=file_path)
    sheet = wb[sheet_name]
    data = {}
    x = 0
    
    for row in sheet.iter_rows(min_row=2, values_only=True):
        for cell in row:
            y = 0
            data (x) = cell
                y = y + 1
        x = x + 1
    return data
